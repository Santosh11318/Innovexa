"use client";

import { motion } from "framer-motion";
import {
  TrendingUp, Target, Rocket, Users, DollarSign,
  Zap, ArrowRight, CheckCircle2, Clock, Star, Brain,
  BarChart3, Globe, Award, ChevronRight,
} from "lucide-react";
import Link from "next/link";

const QUICK_STATS = [
  { label: "Innovation Score", value: "1,240", change: "+12%", icon: TrendingUp, color: "text-blue-500", bg: "bg-blue-500/10" },
  { label: "Problems Solved", value: "8", change: "+2 this week", icon: Target, color: "text-orange-500", bg: "bg-orange-500/10" },
  { label: "Connections", value: "342", change: "+18 this month", icon: Users, color: "text-green-500", bg: "bg-green-500/10" },
  { label: "Builder Level", value: "5", change: "750/1000 XP", icon: Award, color: "text-purple-500", bg: "bg-purple-500/10" },
];

const RECENT_ACTIVITY = [
  { icon: CheckCircle2, color: "text-green-500", text: "Your solution for 'AI Inventory System' was accepted", time: "2h ago" },
  { icon: Users, color: "text-blue-500", text: "Priya Nair (Angel Investor) viewed your startup", time: "4h ago" },
  { icon: Star, color: "text-yellow-500", text: "You earned 'Problem Solver' badge", time: "1d ago" },
  { icon: DollarSign, color: "text-green-500", text: "Meeting request from VentureCap India", time: "2d ago" },
  { icon: Rocket, color: "text-purple-500", text: "Your startup 'FinStack AI' reached 100 followers", time: "3d ago" },
];

const RECOMMENDED_PROBLEMS = [
  {
    id: "1",
    title: "Need AI-powered demand forecasting for D2C brand",
    category: "AI / E-commerce",
    reward: "₹50,000 Cash",
    rewardType: "cash",
    deadline: "5 days",
    solutions: 3,
  },
  {
    id: "2",
    title: "Healthcare app needs telemedicine integration",
    category: "HealthTech",
    reward: "Equity Offer",
    rewardType: "equity",
    deadline: "12 days",
    solutions: 7,
  },
  {
    id: "3",
    title: "Logistics optimization for last-mile delivery startup",
    category: "Logistics",
    reward: "Partnership",
    rewardType: "partnership",
    deadline: "8 days",
    solutions: 12,
  },
];

const AI_SUGGESTIONS = [
  { icon: Brain, text: "Complete your pitch deck — investors are viewing your profile", action: "Open AI Copilot", href: "/dashboard/ai" },
  { icon: Globe, text: "3 investors match your startup stage. Connect now", action: "View Investors", href: "/investors" },
  { icon: Target, text: "New problem posted matching your skills (AI + Finance)", action: "View Problem", href: "/problems" },
];

export default function DashboardPage() {
  return (
    <div className="space-y-8 animate-fade-in">
      {/* Welcome */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Good morning, Arjun 👋</h1>
          <p className="text-muted-foreground mt-1">You have 3 new investor views and 2 pending solutions.</p>
        </div>
        <Link href="/dashboard/ai" className="btn-primary gap-2 hidden sm:flex">
          <Zap className="w-4 h-4" />
          AI Copilot
        </Link>
      </div>

      {/* Quick Stats */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {QUICK_STATS.map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.08 }}
            className="stat-card"
          >
            <div className="flex items-center justify-between">
              <div className={`w-9 h-9 rounded-xl ${stat.bg} flex items-center justify-center`}>
                <stat.icon className={`w-4.5 h-4.5 ${stat.color}`} />
              </div>
              <span className="text-xs text-green-500 font-medium">{stat.change}</span>
            </div>
            <div className="text-2xl font-bold mt-3">{stat.value}</div>
            <div className="text-xs text-muted-foreground">{stat.label}</div>
          </motion.div>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* AI Suggestions */}
        <div className="lg:col-span-2 space-y-6">
          {/* AI Smart Suggestions */}
          <div className="card-premium p-5">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-7 h-7 rounded-lg brand-gradient flex items-center justify-center">
                <Zap className="w-3.5 h-3.5 text-white" />
              </div>
              <h2 className="font-semibold">AI Recommendations</h2>
            </div>
            <div className="space-y-3">
              {AI_SUGGESTIONS.map((s, i) => (
                <div key={i} className="flex items-start gap-3 p-3.5 rounded-xl bg-surface-1 border border-border">
                  <s.icon className="w-4.5 h-4.5 text-primary mt-0.5 flex-shrink-0" />
                  <p className="text-sm flex-1">{s.text}</p>
                  <Link href={s.href} className="text-xs text-primary font-medium hover:underline whitespace-nowrap flex items-center gap-0.5">
                    {s.action} <ChevronRight className="w-3 h-3" />
                  </Link>
                </div>
              ))}
            </div>
          </div>

          {/* Recommended Problems */}
          <div className="card-premium p-5">
            <div className="section-header">
              <div>
                <h2 className="section-title">Recommended Problems</h2>
                <p className="text-xs text-muted-foreground mt-0.5">Matched to your skills</p>
              </div>
              <Link href="/problems" className="btn-ghost text-xs gap-1">
                View all <ArrowRight className="w-3 h-3" />
              </Link>
            </div>
            <div className="space-y-3">
              {RECOMMENDED_PROBLEMS.map((problem) => (
                <Link
                  key={problem.id}
                  href={`/problems/${problem.id}`}
                  className="flex items-start gap-4 p-4 rounded-xl bg-surface-1 border border-border hover:border-primary/30 transition-all group"
                >
                  <div className="flex-1 min-w-0">
                    <div className="font-medium text-sm group-hover:text-primary transition-colors line-clamp-1">
                      {problem.title}
                    </div>
                    <div className="flex items-center gap-3 mt-1.5">
                      <span className="tag text-[10px]">{problem.category}</span>
                      <span className="text-xs text-muted-foreground flex items-center gap-1">
                        <Clock className="w-3 h-3" /> {problem.deadline} left
                      </span>
                      <span className="text-xs text-muted-foreground">{problem.solutions} solutions</span>
                    </div>
                  </div>
                  <div className={`text-xs font-semibold px-2.5 py-1 rounded-lg flex-shrink-0 ${
                    problem.rewardType === "cash"
                      ? "bg-green-500/10 text-green-500"
                      : problem.rewardType === "equity"
                      ? "bg-blue-500/10 text-blue-500"
                      : "bg-purple-500/10 text-purple-500"
                  }`}>
                    {problem.reward}
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column */}
        <div className="space-y-5">
          {/* Quick Actions */}
          <div className="card-premium p-5">
            <h2 className="font-semibold mb-4">Quick Actions</h2>
            <div className="grid grid-cols-2 gap-2">
              {[
                { icon: Rocket, label: "New Startup", href: "/startups/new", color: "text-violet-500 bg-violet-500/10" },
                { icon: Target, label: "Post Problem", href: "/problems/new", color: "text-orange-500 bg-orange-500/10" },
                { icon: Users, label: "Find Talent", href: "/talent", color: "text-green-500 bg-green-500/10" },
                { icon: DollarSign, label: "Raise Funding", href: "/investors", color: "text-blue-500 bg-blue-500/10" },
                { icon: BarChart3, label: "Business Tools", href: "/tools", color: "text-pink-500 bg-pink-500/10" },
                { icon: Brain, label: "AI Copilot", href: "/dashboard/ai", color: "text-primary bg-primary/10" },
              ].map((action) => (
                <Link
                  key={action.label}
                  href={action.href}
                  className="flex flex-col items-center gap-2 p-3 rounded-xl border border-border hover:bg-secondary transition-all text-center group"
                >
                  <div className={`w-9 h-9 rounded-xl ${action.color} flex items-center justify-center group-hover:scale-110 transition-transform`}>
                    <action.icon className="w-4.5 h-4.5" />
                  </div>
                  <span className="text-xs font-medium">{action.label}</span>
                </Link>
              ))}
            </div>
          </div>

          {/* Recent Activity */}
          <div className="card-premium p-5">
            <h2 className="font-semibold mb-4">Recent Activity</h2>
            <div className="space-y-4">
              {RECENT_ACTIVITY.map((activity, i) => (
                <div key={i} className="flex items-start gap-3">
                  <activity.icon className={`w-4 h-4 ${activity.color} mt-0.5 flex-shrink-0`} />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs leading-relaxed">{activity.text}</p>
                    <span className="text-[10px] text-muted-foreground mt-0.5 block">{activity.time}</span>
                  </div>
                </div>
              ))}
            </div>
            <Link href="/dashboard/notifications" className="btn-ghost w-full mt-4 text-xs justify-center">
              View all activity
            </Link>
          </div>

          {/* Profile Completion */}
          <div className="card-premium p-5">
            <div className="flex items-center justify-between mb-3">
              <h2 className="font-semibold text-sm">Profile Strength</h2>
              <span className="text-primary text-sm font-bold">72%</span>
            </div>
            <div className="w-full bg-surface-2 rounded-full h-2 mb-4">
              <div className="bg-gradient-to-r from-primary to-purple-500 h-full rounded-full" style={{ width: "72%" }} />
            </div>
            <div className="space-y-2">
              {[
                { label: "Add Video Introduction", done: false },
                { label: "Upload Pitch Deck", done: true },
                { label: "Add 3 Skills", done: true },
                { label: "Connect LinkedIn", done: false },
              ].map((item) => (
                <div key={item.label} className="flex items-center gap-2 text-xs">
                  <CheckCircle2 className={`w-3.5 h-3.5 ${item.done ? "text-green-500" : "text-muted-foreground/40"}`} />
                  <span className={item.done ? "line-through text-muted-foreground" : ""}>{item.label}</span>
                </div>
              ))}
            </div>
            <Link href="/profile/edit" className="btn-secondary w-full mt-4 text-xs justify-center">
              Complete Profile
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
