"use client";

import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Zap, Send, Sparkles, FileText, BarChart3, Target,
  Users, DollarSign, Globe, Brain, Rocket, ChevronRight,
  Copy, ThumbsUp, RefreshCw, Loader2, TrendingUp,
} from "lucide-react";

const QUICK_PROMPTS = [
  { icon: FileText, label: "Write Business Plan", prompt: "Write a complete business plan for my startup" },
  { icon: BarChart3, label: "Financial Projections", prompt: "Create 3-year financial projections for a SaaS startup" },
  { icon: Target, label: "Go-to-Market Strategy", prompt: "Create a go-to-market strategy for my product" },
  { icon: Globe, label: "Market Research", prompt: "Do market research for the Indian EdTech market" },
  { icon: Users, label: "Customer Persona", prompt: "Create detailed customer personas for a B2B SaaS product" },
  { icon: DollarSign, label: "Fundraising Strategy", prompt: "Help me create a fundraising strategy for Seed round" },
  { icon: Rocket, label: "Pitch Deck Outline", prompt: "Create a compelling pitch deck outline for investors" },
  { icon: Brain, label: "SWOT Analysis", prompt: "Do a SWOT analysis for my fintech startup" },
  { icon: TrendingUp, label: "Competitor Analysis", prompt: "Analyze competitors in the Indian EdTech space" },
];

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
}

export default function AICopilotPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      role: "assistant",
      content: `# Hello! I'm your AI Business Copilot 🚀

I'm here to help you build, scale, and succeed. I can help you with:

- **Business Plans** — Complete plans tailored to your startup
- **Financial Projections** — 3-5 year models and runway calculators
- **Pitch Decks** — Investor-ready slide outlines
- **Market Research** — Deep dives into your target market
- **Go-To-Market Strategy** — Step-by-step launch playbooks
- **SWOT & PESTLE Analysis** — Strategic frameworks
- **Co-founder Matching** — Describe what you need
- **Fundraising Strategy** — Seed to Series A guidance

What do you want to build today?`,
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const sendMessage = async (content: string) => {
    if (!content.trim() || isLoading) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      role: "user",
      content,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setIsLoading(true);

    try {
      const response = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [...messages, userMsg].map((m) => ({
            role: m.role,
            content: m.content,
          })),
        }),
      });

      const data = await response.json();

      const assistantMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: data.content || "I couldn't process that. Please try again.",
        timestamp: new Date(),
      };

      setMessages((prev) => [...prev, assistantMsg]);
    } catch {
      const errorMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: "Sorry, I encountered an error. Please try again.",
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage(input);
    }
  };

  return (
    <div className="flex gap-6 h-[calc(100vh-7rem)] animate-fade-in">
      {/* Sidebar - Quick Prompts */}
      <div className="w-64 flex-shrink-0 flex flex-col gap-4">
        <div className="card-premium p-4">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-7 h-7 rounded-lg brand-gradient flex items-center justify-center">
              <Zap className="w-3.5 h-3.5 text-white" />
            </div>
            <h2 className="font-semibold text-sm">AI Copilot</h2>
          </div>
          <p className="text-xs text-muted-foreground leading-relaxed">
            Your 24/7 AI business consultant. Ask anything about your startup.
          </p>
        </div>

        <div className="card-premium p-3 flex-1 overflow-y-auto no-scrollbar">
          <div className="text-xs font-semibold text-muted-foreground/70 uppercase tracking-wider mb-2 px-1">
            Quick Prompts
          </div>
          <div className="space-y-1">
            {QUICK_PROMPTS.map((prompt) => (
              <button
                key={prompt.label}
                onClick={() => sendMessage(prompt.prompt)}
                disabled={isLoading}
                className="w-full flex items-center gap-2.5 p-2.5 rounded-xl text-left hover:bg-secondary transition-colors group disabled:opacity-50"
              >
                <prompt.icon className="w-3.5 h-3.5 text-primary flex-shrink-0" />
                <span className="text-xs font-medium">{prompt.label}</span>
                <ChevronRight className="w-3 h-3 text-muted-foreground opacity-0 group-hover:opacity-100 ml-auto" />
              </button>
            ))}
          </div>
        </div>

        {/* Model info */}
        <div className="card-premium p-3">
          <div className="flex items-center gap-2 mb-1">
            <Sparkles className="w-3.5 h-3.5 text-primary" />
            <span className="text-xs font-semibold">Powered by Claude</span>
          </div>
          <p className="text-[10px] text-muted-foreground">
            Advanced AI trained on business, startup, and entrepreneurship knowledge.
          </p>
        </div>
      </div>

      {/* Chat area */}
      <div className="flex-1 flex flex-col card-premium overflow-hidden">
        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-5 space-y-5">
          {messages.map((msg) => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex gap-3 ${msg.role === "user" ? "flex-row-reverse" : ""}`}
            >
              {/* Avatar */}
              <div className={`w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 ${
                msg.role === "assistant"
                  ? "brand-gradient"
                  : "bg-primary/20"
              }`}>
                {msg.role === "assistant" ? (
                  <Zap className="w-4 h-4 text-white" />
                ) : (
                  <span className="text-xs font-bold text-primary">A</span>
                )}
              </div>

              {/* Bubble */}
              <div className={`flex-1 max-w-[80%] ${msg.role === "user" ? "flex justify-end" : ""}`}>
                <div className={`rounded-2xl px-4 py-3 text-sm leading-relaxed ${
                  msg.role === "user"
                    ? "bg-primary text-primary-foreground rounded-tr-sm"
                    : "bg-surface-1 border border-border rounded-tl-sm"
                }`}>
                  {msg.role === "assistant" ? (
                    <div className="prose prose-sm dark:prose-invert max-w-none">
                      <div dangerouslySetInnerHTML={{
                        __html: msg.content
                          .replace(/^# (.+)$/gm, '<h1 class="text-base font-bold mb-2">$1</h1>')
                          .replace(/^## (.+)$/gm, '<h2 class="text-sm font-semibold mb-1 mt-3">$2</h2>')
                          .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
                          .replace(/^- (.+)$/gm, '<li class="ml-4 text-xs">$1</li>')
                          .replace(/\n\n/g, '<br/>')
                      }} />
                    </div>
                  ) : (
                    msg.content
                  )}
                </div>

                {/* Actions for AI messages */}
                {msg.role === "assistant" && msg.id !== "welcome" && (
                  <div className="flex items-center gap-1 mt-1.5 ml-1">
                    <button className="btn-ghost w-7 h-7 p-0 text-muted-foreground hover:text-foreground">
                      <Copy className="w-3 h-3" />
                    </button>
                    <button className="btn-ghost w-7 h-7 p-0 text-muted-foreground hover:text-foreground">
                      <ThumbsUp className="w-3 h-3" />
                    </button>
                    <button className="btn-ghost w-7 h-7 p-0 text-muted-foreground hover:text-foreground">
                      <RefreshCw className="w-3 h-3" />
                    </button>
                    <span className="text-[10px] text-muted-foreground ml-1">
                      {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                )}
              </div>
            </motion.div>
          ))}

          {/* Loading */}
          <AnimatePresence>
            {isLoading && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="flex gap-3"
              >
                <div className="w-8 h-8 rounded-xl brand-gradient flex items-center justify-center flex-shrink-0">
                  <Loader2 className="w-4 h-4 text-white animate-spin" />
                </div>
                <div className="bg-surface-1 border border-border rounded-2xl rounded-tl-sm px-4 py-3 flex items-center gap-2">
                  <div className="flex gap-1">
                    {[0, 1, 2].map((i) => (
                      <div
                        key={i}
                        className="w-1.5 h-1.5 rounded-full bg-primary animate-bounce"
                        style={{ animationDelay: `${i * 0.15}s` }}
                      />
                    ))}
                  </div>
                  <span className="text-xs text-muted-foreground">Thinking...</span>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="p-4 border-t border-border">
          <div className="relative flex items-end gap-3">
            <textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Ask your AI Copilot anything about your business..."
              rows={1}
              className="flex-1 input-premium resize-none min-h-[44px] max-h-32 py-3 pr-12"
              style={{ height: "auto" }}
              onInput={(e) => {
                const t = e.target as HTMLTextAreaElement;
                t.style.height = "auto";
                t.style.height = Math.min(t.scrollHeight, 128) + "px";
              }}
            />
            <button
              onClick={() => sendMessage(input)}
              disabled={!input.trim() || isLoading}
              className="absolute right-3 bottom-3 btn-primary w-8 h-8 p-0 disabled:opacity-40"
            >
              <Send className="w-3.5 h-3.5" />
            </button>
          </div>
          <p className="text-[10px] text-muted-foreground mt-2 text-center">
            Press Enter to send · Shift+Enter for new line · Powered by Claude AI
          </p>
        </div>
      </div>
    </div>
  );
}
