"use client";

import { useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { Zap, Mail, Lock, Eye, EyeOff, ArrowRight, Chrome, Github } from "lucide-react";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    // TODO: implement auth
    setTimeout(() => setLoading(false), 1500);
  };

  return (
    <div className="min-h-screen flex">
      {/* Left - Form */}
      <div className="flex-1 flex flex-col items-center justify-center px-6 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-sm"
        >
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 font-bold text-xl mb-8">
            <div className="w-8 h-8 rounded-xl brand-gradient flex items-center justify-center glow">
              <Zap className="w-4 h-4 text-white" />
            </div>
            <span className="brand-gradient-text">Innovexa</span>
          </Link>

          <h1 className="text-2xl font-bold mb-1">Welcome back</h1>
          <p className="text-muted-foreground text-sm mb-8">
            Sign in to continue building.
          </p>

          {/* OAuth */}
          <div className="space-y-3 mb-6">
            <button className="w-full btn-secondary gap-3 py-3">
              <Chrome className="w-4 h-4" />
              Continue with Google
            </button>
            <button className="w-full btn-secondary gap-3 py-3">
              <Github className="w-4 h-4" />
              Continue with GitHub
            </button>
          </div>

          <div className="divider-with-text mb-6">
            <span>or continue with email</span>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-sm font-medium">Email</label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className="input-premium pl-10"
                  required
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium">Password</label>
                <Link href="/auth/forgot-password" className="text-xs text-primary hover:underline">
                  Forgot password?
                </Link>
              </div>
              <div className="relative">
                <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="input-premium pl-10 pr-10"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="btn-primary w-full py-3 mt-2"
            >
              {loading ? (
                <span className="flex items-center gap-2">
                  <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Signing in...
                </span>
              ) : (
                <span className="flex items-center gap-2">
                  Sign In <ArrowRight className="w-4 h-4" />
                </span>
              )}
            </button>
          </form>

          <p className="text-sm text-center text-muted-foreground mt-6">
            Don't have an account?{" "}
            <Link href="/auth/register" className="text-primary font-medium hover:underline">
              Create one free
            </Link>
          </p>
        </motion.div>
      </div>

      {/* Right - Brand Panel */}
      <div className="hidden lg:flex flex-1 relative overflow-hidden brand-gradient items-center justify-center p-12">
        <div className="absolute inset-0 bg-black/20" />
        <div className="absolute inset-0 bg-grid-pattern opacity-20" />
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
          className="relative z-10 text-white max-w-md"
        >
          <h2 className="text-3xl font-bold mb-4 leading-tight">
            Build the future,<br />one startup at a time.
          </h2>
          <p className="text-white/80 text-lg mb-8 leading-relaxed">
            Join 85,000+ entrepreneurs, investors, and innovators building the next generation of companies.
          </p>
          <div className="space-y-3">
            {[
              "✓ AI-powered business plan generator",
              "✓ Co-founder and investor matching",
              "✓ Problem Marketplace with real rewards",
              "✓ Expert mentors on-demand",
            ].map((item) => (
              <div key={item} className="text-white/90 text-sm font-medium">{item}</div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
