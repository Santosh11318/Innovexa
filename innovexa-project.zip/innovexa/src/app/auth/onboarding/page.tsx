"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Zap, Rocket, DollarSign, GraduationCap, Star, Code2,
  Palette, TrendingUp, Brain, Package, Briefcase, Users,
  ShoppingCart, Wrench, Building2, Lightbulb, ArrowRight,
  ArrowLeft, CheckCircle2, Globe,
} from "lucide-react";
import { useRouter } from "next/navigation";
import { cn } from "@/lib/utils/cn";

const ROLES = [
  { id: "FOUNDER", icon: Rocket, label: "Founder", desc: "Building a startup", color: "from-violet-500 to-purple-600" },
  { id: "INVESTOR", icon: DollarSign, label: "Investor", desc: "Angel / VC investor", color: "from-green-500 to-emerald-600" },
  { id: "STUDENT", icon: GraduationCap, label: "Student", desc: "Learning & exploring", color: "from-blue-500 to-cyan-600" },
  { id: "MENTOR", icon: Star, label: "Mentor", desc: "Guiding founders", color: "from-yellow-500 to-amber-600" },
  { id: "DEVELOPER", icon: Code2, label: "Developer", desc: "Building products", color: "from-slate-500 to-gray-600" },
  { id: "DESIGNER", icon: Palette, label: "Designer", desc: "Creating experiences", color: "from-pink-500 to-rose-600" },
  { id: "MARKETING_EXPERT", icon: TrendingUp, label: "Marketing", desc: "Growing businesses", color: "from-orange-500 to-red-500" },
  { id: "AI_ENGINEER", icon: Brain, label: "AI Engineer", desc: "Building AI systems", color: "from-indigo-500 to-violet-600" },
  { id: "PRODUCT_MANAGER", icon: Package, label: "Product Manager", desc: "Leading products", color: "from-teal-500 to-cyan-600" },
  { id: "BUSINESS_CONSULTANT", icon: Briefcase, label: "Consultant", desc: "Advising businesses", color: "from-stone-500 to-stone-600" },
  { id: "FREELANCER", icon: Globe, label: "Freelancer", desc: "Independent work", color: "from-sky-500 to-blue-600" },
  { id: "INNOVATION_ENTHUSIAST", icon: Lightbulb, label: "Innovator", desc: "Solving problems", color: "from-amber-500 to-yellow-600" },
];

const GOALS = [
  { id: "find_cofounder", label: "Find a Co-founder", icon: Users },
  { id: "raise_funding", label: "Raise Funding", icon: DollarSign },
  { id: "build_startup", label: "Build a Startup", icon: Rocket },
  { id: "solve_problems", label: "Solve Problems", icon: Lightbulb },
  { id: "find_talent", label: "Hire Talent", icon: Users },
  { id: "find_mentor", label: "Get Mentorship", icon: Star },
  { id: "learn", label: "Learn Business", icon: GraduationCap },
  { id: "invest", label: "Invest in Startups", icon: DollarSign },
];

const INDUSTRIES = [
  "FinTech", "HealthTech", "EdTech", "AgriTech", "CleanTech",
  "AI / ML", "SaaS", "E-commerce", "Logistics", "Manufacturing",
  "Real Estate", "HR Tech", "Legal Tech", "Marketing Tech", "Gaming",
  "Web3 / Crypto", "IoT", "Robotics", "BioTech", "Media & Content",
];

const STEPS = ["Your Role", "Your Goals", "Industries", "Profile Setup"];

export default function OnboardingPage() {
  const router = useRouter();
  const [step, setStep] = useState(0);
  const [selectedRoles, setSelectedRoles] = useState<string[]>([]);
  const [selectedGoals, setSelectedGoals] = useState<string[]>([]);
  const [selectedIndustries, setSelectedIndustries] = useState<string[]>([]);
  const [profile, setProfile] = useState({ headline: "", location: "", lookingFor: "" });

  const toggleRole = (id: string) => {
    setSelectedRoles((prev) =>
      prev.includes(id) ? prev.filter((r) => r !== id) : [...prev, id]
    );
  };

  const toggleGoal = (id: string) => {
    setSelectedGoals((prev) =>
      prev.includes(id) ? prev.filter((g) => g !== id) : [...prev, id]
    );
  };

  const toggleIndustry = (ind: string) => {
    setSelectedIndustries((prev) =>
      prev.includes(ind) ? prev.filter((i) => i !== ind) : prev.length < 5 ? [...prev, ind] : prev
    );
  };

  const canNext = () => {
    if (step === 0) return selectedRoles.length > 0;
    if (step === 1) return selectedGoals.length > 0;
    if (step === 2) return selectedIndustries.length > 0;
    return profile.headline.length > 5;
  };

  const handleNext = () => {
    if (step < STEPS.length - 1) setStep(step + 1);
    else router.push("/dashboard");
  };

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center px-4 py-12">
      {/* Logo */}
      <div className="flex items-center gap-2 font-bold text-xl mb-10">
        <div className="w-8 h-8 rounded-xl brand-gradient flex items-center justify-center glow">
          <Zap className="w-4 h-4 text-white" />
        </div>
        <span className="brand-gradient-text">Innovexa</span>
      </div>

      {/* Progress */}
      <div className="w-full max-w-2xl mb-8">
        <div className="flex items-center gap-2 mb-3">
          {STEPS.map((s, i) => (
            <div key={s} className="flex items-center gap-2 flex-1">
              <div className={cn(
                "w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 transition-all",
                i < step ? "brand-gradient text-white" :
                i === step ? "border-2 border-primary text-primary" :
                "border-2 border-border text-muted-foreground"
              )}>
                {i < step ? <CheckCircle2 className="w-4 h-4" /> : i + 1}
              </div>
              {i < STEPS.length - 1 && (
                <div className={cn("h-0.5 flex-1 transition-all", i < step ? "bg-primary" : "bg-border")} />
              )}
            </div>
          ))}
        </div>
        <div className="flex justify-between text-xs text-muted-foreground px-0.5">
          {STEPS.map((s, i) => (
            <span key={s} className={cn(i === step && "text-primary font-medium")}>{s}</span>
          ))}
        </div>
      </div>

      {/* Card */}
      <div className="w-full max-w-2xl card-premium p-8">
        <AnimatePresence mode="wait">
          {/* Step 0 - Roles */}
          {step === 0 && (
            <motion.div key="step0" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
              <h1 className="text-2xl font-bold mb-1">Who are you?</h1>
              <p className="text-muted-foreground text-sm mb-6">Select all roles that describe you. You can update this anytime.</p>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {ROLES.map((role) => {
                  const selected = selectedRoles.includes(role.id);
                  return (
                    <button
                      key={role.id}
                      onClick={() => toggleRole(role.id)}
                      className={cn(
                        "flex items-center gap-3 p-3.5 rounded-xl border-2 text-left transition-all",
                        selected
                          ? "border-primary bg-primary/5"
                          : "border-border hover:border-primary/40 hover:bg-surface-1"
                      )}
                    >
                      <div className={cn("w-9 h-9 rounded-xl bg-gradient-to-br flex items-center justify-center flex-shrink-0", role.color)}>
                        <role.icon className="w-4.5 h-4.5 text-white" />
                      </div>
                      <div>
                        <div className="text-sm font-semibold">{role.label}</div>
                        <div className="text-[10px] text-muted-foreground">{role.desc}</div>
                      </div>
                      {selected && <CheckCircle2 className="w-4 h-4 text-primary ml-auto flex-shrink-0" />}
                    </button>
                  );
                })}
              </div>
            </motion.div>
          )}

          {/* Step 1 - Goals */}
          {step === 1 && (
            <motion.div key="step1" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
              <h1 className="text-2xl font-bold mb-1">What are your goals?</h1>
              <p className="text-muted-foreground text-sm mb-6">Tell us what you want to achieve. Select all that apply.</p>
              <div className="grid grid-cols-2 gap-3">
                {GOALS.map((goal) => {
                  const selected = selectedGoals.includes(goal.id);
                  return (
                    <button
                      key={goal.id}
                      onClick={() => toggleGoal(goal.id)}
                      className={cn(
                        "flex items-center gap-3 p-4 rounded-xl border-2 text-left transition-all",
                        selected ? "border-primary bg-primary/5" : "border-border hover:border-primary/40 hover:bg-surface-1"
                      )}
                    >
                      <goal.icon className={cn("w-5 h-5 flex-shrink-0", selected ? "text-primary" : "text-muted-foreground")} />
                      <span className="text-sm font-medium">{goal.label}</span>
                      {selected && <CheckCircle2 className="w-4 h-4 text-primary ml-auto" />}
                    </button>
                  );
                })}
              </div>
            </motion.div>
          )}

          {/* Step 2 - Industries */}
          {step === 2 && (
            <motion.div key="step2" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
              <h1 className="text-2xl font-bold mb-1">Your Industries</h1>
              <p className="text-muted-foreground text-sm mb-6">
                Select up to 5 industries you're interested in.{" "}
                <span className="text-primary">{selectedIndustries.length}/5 selected</span>
              </p>
              <div className="flex flex-wrap gap-2.5">
                {INDUSTRIES.map((ind) => {
                  const selected = selectedIndustries.includes(ind);
                  return (
                    <button
                      key={ind}
                      onClick={() => toggleIndustry(ind)}
                      className={cn(
                        "px-4 py-2 rounded-xl border-2 text-sm font-medium transition-all",
                        selected
                          ? "border-primary bg-primary text-primary-foreground"
                          : "border-border hover:border-primary/40 text-foreground"
                      )}
                    >
                      {ind}
                    </button>
                  );
                })}
              </div>
            </motion.div>
          )}

          {/* Step 3 - Profile */}
          {step === 3 && (
            <motion.div key="step3" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
              <h1 className="text-2xl font-bold mb-1">Set Up Your Profile</h1>
              <p className="text-muted-foreground text-sm mb-6">Help others understand who you are and what you're looking for.</p>
              <div className="space-y-5">
                <div className="space-y-1.5">
                  <label className="text-sm font-medium">Professional Headline *</label>
                  <input
                    type="text"
                    value={profile.headline}
                    onChange={(e) => setProfile({ ...profile, headline: e.target.value })}
                    placeholder="e.g. Founder building AI tools for SMEs | Ex-Google"
                    className="input-premium"
                    maxLength={120}
                  />
                  <p className="text-xs text-muted-foreground">{profile.headline.length}/120</p>
                </div>
                <div className="space-y-1.5">
                  <label className="text-sm font-medium">Location</label>
                  <input
                    type="text"
                    value={profile.location}
                    onChange={(e) => setProfile({ ...profile, location: e.target.value })}
                    placeholder="e.g. Bengaluru, India"
                    className="input-premium"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-sm font-medium">I'm Looking For</label>
                  <input
                    type="text"
                    value={profile.lookingFor}
                    onChange={(e) => setProfile({ ...profile, lookingFor: e.target.value })}
                    placeholder="e.g. Technical co-founder, seed investment, mentorship"
                    className="input-premium"
                  />
                </div>

                {/* Summary */}
                <div className="p-4 rounded-xl bg-primary/5 border border-primary/20 space-y-2">
                  <div className="text-sm font-semibold">Your Profile Summary</div>
                  <div className="flex flex-wrap gap-1.5">
                    {selectedRoles.slice(0, 3).map((r) => (
                      <span key={r} className="tag">{ROLES.find(ro => ro.id === r)?.label}</span>
                    ))}
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {selectedIndustries.slice(0, 4).map((i) => (
                      <span key={i} className="px-2 py-0.5 rounded-full bg-secondary text-xs">{i}</span>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Navigation */}
        <div className="flex items-center justify-between mt-8 pt-6 border-t border-border">
          <button
            onClick={() => setStep(Math.max(0, step - 1))}
            disabled={step === 0}
            className="btn-ghost gap-2 disabled:opacity-30"
          >
            <ArrowLeft className="w-4 h-4" /> Back
          </button>
          <button
            onClick={handleNext}
            disabled={!canNext()}
            className="btn-primary gap-2 px-6 disabled:opacity-40"
          >
            {step === STEPS.length - 1 ? (
              <>Launch My Dashboard <Zap className="w-4 h-4" /></>
            ) : (
              <>Continue <ArrowRight className="w-4 h-4" /></>
            )}
          </button>
        </div>
      </div>

      <p className="text-xs text-muted-foreground mt-6">
        You can update all of this in your profile settings anytime.
      </p>
    </div>
  );
}
