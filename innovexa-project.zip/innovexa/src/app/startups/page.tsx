"use client";

import { useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  Rocket, Plus, TrendingUp, Users, DollarSign, Globe,
  Edit3, Eye, Star, ChevronRight, Building2, Target,
  BarChart3, Calendar, Zap, ArrowRight,
} from "lucide-react";
import { cn } from "@/lib/utils/cn";

const MOCK_STARTUPS = [
  {
    id: "1",
    name: "FinStack AI",
    slug: "finstack-ai",
    logo: null,
    tagline: "AI-powered financial analytics for SMEs",
    stage: "SEED",
    industry: ["FinTech", "AI"],
    teamSize: 4,
    followers: 234,
    fundingRaised: 2500000,
    monthlyRevenue: 180000,
    growth: 23,
    status: "ACTIVE",
    isOwner: true,
  },
  {
    id: "2",
    name: "AgroSense",
    slug: "agrosense",
    logo: null,
    tagline: "IoT sensors for precision farming",
    stage: "PRE_SEED",
    industry: ["AgriTech", "IoT"],
    teamSize: 2,
    followers: 87,
    fundingRaised: 0,
    monthlyRevenue: 0,
    growth: 0,
    status: "BUILDING",
    isOwner: true,
  },
];

const STAGE_COLORS: Record<string, string> = {
  IDEA: "bg-gray-500/10 text-gray-500",
  PRE_SEED: "bg-blue-500/10 text-blue-500",
  SEED: "bg-green-500/10 text-green-500",
  SERIES_A: "bg-purple-500/10 text-purple-500",
  SERIES_B: "bg-orange-500/10 text-orange-500",
  GROWTH: "bg-pink-500/10 text-pink-500",
};

function StartupCard({ startup }: { startup: typeof MOCK_STARTUPS[0] }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="card-premium p-6 group"
    >
      {/* Header */}
      <div className="flex items-start gap-4 mb-4">
        <div className="w-14 h-14 rounded-2xl brand-gradient flex items-center justify-center text-white font-bold text-xl flex-shrink-0">
          {startup.name[0]}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <h3 className="font-bold text-base">{startup.name}</h3>
            <span className={cn("badge-level text-[10px]", STAGE_COLORS[startup.stage])}>
              {startup.stage.replace("_", " ")}
            </span>
          </div>
          <p className="text-sm text-muted-foreground mt-0.5 line-clamp-1">{startup.tagline}</p>
          <div className="flex flex-wrap gap-1 mt-1.5">
            {startup.industry.map((ind) => (
              <span key={ind} className="tag text-[10px]">{ind}</span>
            ))}
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-3 py-4 border-y border-border mb-4">
        {[
          { label: "Team", value: startup.teamSize, icon: Users },
          { label: "Followers", value: startup.followers, icon: Star },
          {
            label: "Raised",
            value: startup.fundingRaised > 0 ? `₹${(startup.fundingRaised / 100000).toFixed(1)}L` : "—",
            icon: DollarSign,
          },
          {
            label: "MRR",
            value: startup.monthlyRevenue > 0 ? `₹${(startup.monthlyRevenue / 1000).toFixed(0)}K` : "—",
            icon: BarChart3,
          },
        ].map((stat) => (
          <div key={stat.label} className="text-center">
            <stat.icon className="w-3.5 h-3.5 text-muted-foreground mx-auto mb-1" />
            <div className="text-sm font-bold">{stat.value}</div>
            <div className="text-[10px] text-muted-foreground">{stat.label}</div>
          </div>
        ))}
      </div>

      {/* Actions */}
      <div className="flex items-center gap-2">
        <Link href={`/startups/${startup.slug}/edit`} className="btn-secondary flex-1 text-xs gap-1.5 py-2">
          <Edit3 className="w-3.5 h-3.5" /> Edit
        </Link>
        <Link href={`/startups/${startup.slug}`} className="btn-ghost flex-1 text-xs gap-1.5 py-2">
          <Eye className="w-3.5 h-3.5" /> View
        </Link>
        <Link href={`/startups/${startup.slug}/workspace`} className="btn-primary flex-1 text-xs gap-1.5 py-2">
          <Target className="w-3.5 h-3.5" /> Manage
        </Link>
      </div>
    </motion.div>
  );
}

export default function StartupsPage() {
  const [view, setView] = useState<"my" | "discover">("my");

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <Rocket className="w-6 h-6 text-violet-500" />
            Startup Builder
          </h1>
          <p className="text-muted-foreground mt-1 text-sm">
            Build, manage, and scale your startups with AI.
          </p>
        </div>
        <Link href="/startups/new" className="btn-primary">
          <Plus className="w-4 h-4" /> New Startup
        </Link>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 p-1 bg-surface-1 border border-border rounded-xl w-fit">
        {[
          { id: "my", label: "My Startups" },
          { id: "discover", label: "Discover Startups" },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setView(tab.id as "my" | "discover")}
            className={cn(
              "px-4 py-2 rounded-lg text-sm font-medium transition-all",
              view === tab.id
                ? "bg-background text-foreground shadow-sm"
                : "text-muted-foreground hover:text-foreground"
            )}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {view === "my" && (
        <>
          {/* AI Copilot banner */}
          <div className="p-4 rounded-2xl border border-primary/30 bg-primary/5 flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl brand-gradient flex items-center justify-center flex-shrink-0">
              <Zap className="w-4.5 h-4.5 text-white" />
            </div>
            <div className="flex-1">
              <div className="font-semibold text-sm">AI Startup Copilot Ready</div>
              <div className="text-xs text-muted-foreground mt-0.5">
                Generate business plans, pitch decks, financial models in seconds
              </div>
            </div>
            <Link href="/dashboard/ai" className="btn-primary text-xs px-3 py-1.5 flex-shrink-0">
              Open AI Copilot <ArrowRight className="w-3 h-3" />
            </Link>
          </div>

          {/* My Startups */}
          <div className="grid sm:grid-cols-2 gap-5">
            {MOCK_STARTUPS.map((s) => (
              <StartupCard key={s.id} startup={s} />
            ))}

            {/* Create new card */}
            <Link
              href="/startups/new"
              className="card-premium p-6 flex flex-col items-center justify-center gap-3 border-2 border-dashed hover:border-primary/50 hover:bg-primary/5 transition-all min-h-[200px] group"
            >
              <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center group-hover:scale-110 transition-transform">
                <Plus className="w-6 h-6 text-primary" />
              </div>
              <div className="text-center">
                <div className="font-semibold text-sm">Create New Startup</div>
                <div className="text-xs text-muted-foreground mt-1">Build unlimited startups</div>
              </div>
            </Link>
          </div>

          {/* Quick links */}
          <div className="grid sm:grid-cols-3 gap-4">
            {[
              { icon: BarChart3, label: "Business Tools", desc: "Calculators & Templates", href: "/tools", color: "text-blue-500 bg-blue-500/10" },
              { icon: Globe, label: "Market Research", desc: "AI-powered insights", href: "/dashboard/ai", color: "text-green-500 bg-green-500/10" },
              { icon: DollarSign, label: "Raise Funding", desc: "Connect with investors", href: "/investors", color: "text-yellow-500 bg-yellow-500/10" },
            ].map((item) => (
              <Link key={item.label} href={item.href} className="card-premium p-4 flex items-center gap-3 hover:border-primary/30 transition-all group">
                <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform", item.color)}>
                  <item.icon className="w-5 h-5" />
                </div>
                <div>
                  <div className="font-semibold text-sm">{item.label}</div>
                  <div className="text-xs text-muted-foreground">{item.desc}</div>
                </div>
                <ChevronRight className="w-4 h-4 text-muted-foreground ml-auto opacity-0 group-hover:opacity-100 transition-opacity" />
              </Link>
            ))}
          </div>
        </>
      )}

      {view === "discover" && (
        <div className="text-center py-16 text-muted-foreground">
          <Building2 className="w-12 h-12 mx-auto mb-4 opacity-30" />
          <div className="font-semibold">Discover Startups</div>
          <div className="text-sm mt-1">Explore 12,000+ startups from across India and the world</div>
          <button className="btn-primary mt-4">Browse Startups</button>
        </div>
      )}
    </div>
  );
}
