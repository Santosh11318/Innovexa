"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import {
  Rocket, ArrowLeft, ArrowRight, CheckCircle2, Zap,
  Upload, Globe, DollarSign, Users, Target, BarChart3,
} from "lucide-react";
import Link from "next/link";
import { cn } from "@/lib/utils/cn";

const STAGES = [
  { id: "IDEA", label: "Idea Stage", desc: "Still exploring" },
  { id: "PRE_SEED", label: "Pre-Seed", desc: "Prototype / MVP" },
  { id: "SEED", label: "Seed", desc: "Early revenue" },
  { id: "SERIES_A", label: "Series A", desc: "Scaling" },
  { id: "SERIES_B", label: "Series B", desc: "Growth" },
  { id: "GROWTH", label: "Growth", desc: "Mature" },
];

const INDUSTRIES = [
  "FinTech", "HealthTech", "EdTech", "AgriTech", "CleanTech",
  "AI / ML", "SaaS", "E-commerce", "Logistics", "Manufacturing",
  "Real Estate", "HR Tech", "Legal Tech", "Marketing Tech",
  "Gaming", "Web3", "IoT", "Robotics", "BioTech", "Media",
];

const STEPS = [
  { label: "Basic Info", icon: Rocket },
  { label: "Problem & Solution", icon: Target },
  { label: "Business Model", icon: DollarSign },
  { label: "Team & Funding", icon: Users },
];

export default function NewStartupPage() {
  const router = useRouter();
  const [step, setStep] = useState(0);
  const [aiGenerating, setAiGenerating] = useState(false);
  const [form, setForm] = useState({
    name: "",
    tagline: "",
    description: "",
    stage: "IDEA",
    industries: [] as string[],
    website: "",
    problem: "",
    solution: "",
    businessModel: "",
    revenueModel: "",
    marketSize: "",
    fundingTarget: "",
    teamSize: "1",
    lookingFor: [] as string[],
  });

  const update = (field: string, value: any) =>
    setForm((prev) => ({ ...prev, [field]: value }));

  const toggleIndustry = (ind: string) => {
    const current = form.industries;
    update(
      "industries",
      current.includes(ind) ? current.filter((i) => i !== ind) : current.length < 5 ? [...current, ind] : current
    );
  };

  const handleAiGenerate = async (field: string) => {
    setAiGenerating(true);
    setTimeout(() => {
      if (field === "description") {
        update("description", `${form.name} is an innovative ${form.industries[0] || "tech"} startup that ${form.problem ? "solves the problem of " + form.problem.toLowerCase() : "creates value for customers"} through cutting-edge technology and a customer-first approach.`);
      } else if (field === "solution") {
        update("solution", `Our platform leverages AI and modern technology to provide an end-to-end solution that reduces friction, improves efficiency, and delivers measurable ROI for our users.`);
      }
      setAiGenerating(false);
    }, 1500);
  };

  const canNext = () => {
    if (step === 0) return form.name.length >= 2 && form.stage;
    if (step === 1) return form.problem.length > 10;
    if (step === 2) return form.businessModel.length > 10;
    return true;
  };

  const handleSubmit = () => {
    // TODO: API call
    router.push("/startups");
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6 animate-fade-in">
      {/* Back */}
      <Link href="/startups" className="btn-ghost text-sm gap-2 inline-flex">
        <ArrowLeft className="w-4 h-4" /> Back to Startups
      </Link>

      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold">Create New Startup</h1>
        <p className="text-muted-foreground text-sm mt-1">
          Build your startup profile. Use AI to generate content instantly.
        </p>
      </div>

      {/* Progress */}
      <div className="flex items-center gap-2">
        {STEPS.map((s, i) => (
          <div key={s.label} className="flex items-center gap-2 flex-1">
            <button
              onClick={() => i < step && setStep(i)}
              className={cn(
                "w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all flex-shrink-0",
                i < step ? "brand-gradient text-white cursor-pointer" :
                i === step ? "border-2 border-primary text-primary bg-primary/5" :
                "border-2 border-border text-muted-foreground"
              )}
            >
              {i < step ? <CheckCircle2 className="w-4 h-4" /> : i + 1}
            </button>
            {i < STEPS.length - 1 && (
              <div className={cn("h-0.5 flex-1", i < step ? "bg-primary" : "bg-border")} />
            )}
          </div>
        ))}
      </div>

      {/* Form */}
      <div className="card-premium p-6">
        <AnimatePresence mode="wait">
          {/* Step 0: Basic Info */}
          {step === 0 && (
            <motion.div key="s0" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-5">
              <h2 className="font-semibold text-lg">Basic Information</h2>

              <div className="space-y-1.5">
                <label className="text-sm font-medium">Startup Name *</label>
                <input
                  type="text"
                  value={form.name}
                  onChange={(e) => update("name", e.target.value)}
                  placeholder="e.g. FinStack AI"
                  className="input-premium"
                />
              </div>

              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium">Tagline *</label>
                  <button
                    onClick={() => update("tagline", `AI-powered ${form.industries[0] || "tech"} platform for ${form.name || "modern businesses"}`)}
                    className="text-xs text-primary flex items-center gap-1 hover:underline"
                  >
                    <Zap className="w-3 h-3" /> AI Generate
                  </button>
                </div>
                <input
                  type="text"
                  value={form.tagline}
                  onChange={(e) => update("tagline", e.target.value)}
                  placeholder="e.g. AI-powered financial analytics for SMEs"
                  className="input-premium"
                  maxLength={120}
                />
              </div>

              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium">Description</label>
                  <button
                    onClick={() => handleAiGenerate("description")}
                    disabled={aiGenerating}
                    className="text-xs text-primary flex items-center gap-1 hover:underline disabled:opacity-50"
                  >
                    <Zap className="w-3 h-3" /> {aiGenerating ? "Generating..." : "AI Generate"}
                  </button>
                </div>
                <textarea
                  value={form.description}
                  onChange={(e) => update("description", e.target.value)}
                  placeholder="Describe your startup in 2-3 sentences..."
                  className="input-premium min-h-[90px] resize-none"
                  rows={3}
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-sm font-medium">Stage *</label>
                <div className="grid grid-cols-3 gap-2">
                  {STAGES.map((stage) => (
                    <button
                      key={stage.id}
                      onClick={() => update("stage", stage.id)}
                      className={cn(
                        "p-3 rounded-xl border-2 text-left transition-all",
                        form.stage === stage.id ? "border-primary bg-primary/5" : "border-border hover:border-primary/40"
                      )}
                    >
                      <div className="text-xs font-semibold">{stage.label}</div>
                      <div className="text-[10px] text-muted-foreground">{stage.desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-sm font-medium">Industries (max 5)</label>
                <div className="flex flex-wrap gap-2">
                  {INDUSTRIES.map((ind) => (
                    <button
                      key={ind}
                      onClick={() => toggleIndustry(ind)}
                      className={cn(
                        "px-3 py-1.5 rounded-lg border text-xs font-medium transition-all",
                        form.industries.includes(ind)
                          ? "border-primary bg-primary text-primary-foreground"
                          : "border-border hover:border-primary/40"
                      )}
                    >
                      {ind}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-sm font-medium">Website</label>
                <div className="relative">
                  <Globe className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <input
                    type="url"
                    value={form.website}
                    onChange={(e) => update("website", e.target.value)}
                    placeholder="https://yourstartup.com"
                    className="input-premium pl-10"
                  />
                </div>
              </div>
            </motion.div>
          )}

          {/* Step 1: Problem & Solution */}
          {step === 1 && (
            <motion.div key="s1" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-5">
              <h2 className="font-semibold text-lg">Problem & Solution</h2>

              <div className="space-y-1.5">
                <label className="text-sm font-medium">Problem You're Solving *</label>
                <textarea
                  value={form.problem}
                  onChange={(e) => update("problem", e.target.value)}
                  placeholder="What specific problem does your startup solve? Be specific and use data if possible."
                  className="input-premium min-h-[100px] resize-none"
                  rows={4}
                />
              </div>

              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium">Your Solution</label>
                  <button
                    onClick={() => handleAiGenerate("solution")}
                    disabled={aiGenerating}
                    className="text-xs text-primary flex items-center gap-1 hover:underline disabled:opacity-50"
                  >
                    <Zap className="w-3 h-3" /> {aiGenerating ? "Generating..." : "AI Generate"}
                  </button>
                </div>
                <textarea
                  value={form.solution}
                  onChange={(e) => update("solution", e.target.value)}
                  placeholder="How does your startup solve this problem? What makes your approach unique?"
                  className="input-premium min-h-[100px] resize-none"
                  rows={4}
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-sm font-medium">Market Size</label>
                <input
                  type="text"
                  value={form.marketSize}
                  onChange={(e) => update("marketSize", e.target.value)}
                  placeholder="e.g. ₹50,000 Cr TAM, ₹5,000 Cr SAM"
                  className="input-premium"
                />
              </div>
            </motion.div>
          )}

          {/* Step 2: Business Model */}
          {step === 2 && (
            <motion.div key="s2" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-5">
              <h2 className="font-semibold text-lg">Business Model</h2>

              <div className="space-y-1.5">
                <label className="text-sm font-medium">Business Model *</label>
                <textarea
                  value={form.businessModel}
                  onChange={(e) => update("businessModel", e.target.value)}
                  placeholder="Describe how your startup creates and delivers value. e.g. B2B SaaS, marketplace, D2C..."
                  className="input-premium min-h-[100px] resize-none"
                  rows={4}
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-sm font-medium">Revenue Model</label>
                <textarea
                  value={form.revenueModel}
                  onChange={(e) => update("revenueModel", e.target.value)}
                  placeholder="How do you make money? e.g. Subscription (₹999/month), commission (5%), one-time fee..."
                  className="input-premium min-h-[80px] resize-none"
                  rows={3}
                />
              </div>

              {/* AI Suggestion */}
              <div className="p-4 rounded-xl border border-primary/20 bg-primary/5">
                <div className="flex items-center gap-2 mb-2">
                  <Zap className="w-4 h-4 text-primary" />
                  <span className="text-sm font-semibold">AI Copilot can generate:</span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {["Business Model Canvas", "Lean Canvas", "Financial Projections", "Go-to-Market Strategy"].map((item) => (
                    <Link
                      key={item}
                      href="/dashboard/ai"
                      className="text-xs text-primary hover:underline flex items-center gap-1"
                    >
                      → {item}
                    </Link>
                  ))}
                </div>
              </div>
            </motion.div>
          )}

          {/* Step 3: Team & Funding */}
          {step === 3 && (
            <motion.div key="s3" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-5">
              <h2 className="font-semibold text-lg">Team & Funding</h2>

              <div className="space-y-1.5">
                <label className="text-sm font-medium">Team Size</label>
                <select
                  value={form.teamSize}
                  onChange={(e) => update("teamSize", e.target.value)}
                  className="input-premium"
                >
                  {["1", "2", "3-5", "6-10", "11-25", "25+"].map((s) => (
                    <option key={s} value={s}>{s} {s === "1" ? "person (solo)" : "people"}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-sm font-medium">Funding Target (₹)</label>
                <input
                  type="text"
                  value={form.fundingTarget}
                  onChange={(e) => update("fundingTarget", e.target.value)}
                  placeholder="e.g. 50,00,000 (₹50 Lakhs)"
                  className="input-premium"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-sm font-medium">Looking For</label>
                <div className="flex flex-wrap gap-2">
                  {["Co-founder", "Investor", "Developer", "Designer", "Marketing Expert", "Mentor", "Advisor", "Team Members"].map((item) => (
                    <button
                      key={item}
                      onClick={() => {
                        const current = form.lookingFor;
                        update("lookingFor", current.includes(item) ? current.filter((i) => i !== item) : [...current, item]);
                      }}
                      className={cn(
                        "px-3 py-1.5 rounded-lg border text-xs font-medium transition-all",
                        form.lookingFor.includes(item)
                          ? "border-primary bg-primary text-primary-foreground"
                          : "border-border hover:border-primary/40"
                      )}
                    >
                      {item}
                    </button>
                  ))}
                </div>
              </div>

              {/* Logo upload placeholder */}
              <div className="space-y-1.5">
                <label className="text-sm font-medium">Logo (optional)</label>
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-2xl brand-gradient flex items-center justify-center text-white font-bold text-2xl flex-shrink-0">
                    {form.name?.[0] || "?"}
                  </div>
                  <button className="btn-secondary text-sm gap-2">
                    <Upload className="w-4 h-4" /> Upload Logo
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Navigation */}
        <div className="flex items-center justify-between mt-8 pt-6 border-t border-border">
          <button
            onClick={() => setStep(Math.max(0, step - 1))}
            disabled={step === 0}
            className="btn-ghost gap-2 disabled:opacity-30"
          >
            <ArrowLeft className="w-4 h-4" /> Back
          </button>

          {step < STEPS.length - 1 ? (
            <button
              onClick={() => setStep(step + 1)}
              disabled={!canNext()}
              className="btn-primary gap-2 disabled:opacity-40"
            >
              Continue <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <button onClick={handleSubmit} className="btn-primary gap-2">
              <Rocket className="w-4 h-4" /> Launch Startup
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
