"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import {
  Briefcase, Search, MapPin, Clock, DollarSign,
  CheckCircle2, Star, Zap, Plus, Users, Code2,
  Palette, TrendingUp, Brain, ArrowRight,
} from "lucide-react";
import Link from "next/link";
import { cn } from "@/lib/utils/cn";

const JOB_TYPES = ["All", "Full-time", "Part-time", "Contract", "Internship", "Co-founder"];
const ROLES = ["All Roles", "Developer", "Designer", "AI Engineer", "Product Manager", "Marketing", "Sales", "Finance", "Legal"];

const MOCK_JOBS = [
  {
    id: "1",
    title: "Senior Full-Stack Developer (React + Node)",
    company: "FinStack AI",
    logo: "FS",
    location: "Bengaluru",
    isRemote: true,
    type: "Full-time",
    salaryMin: 25,
    salaryMax: 45,
    equity: 0.5,
    skills: ["React", "Node.js", "TypeScript", "PostgreSQL"],
    postedAt: "2 days ago",
    applicants: 34,
    isVerified: true,
    stage: "Seed",
  },
  {
    id: "2",
    title: "Co-founder (Technical) — AI Healthcare Startup",
    company: "MedAI (Stealth)",
    logo: "MA",
    location: "Remote",
    isRemote: true,
    type: "Co-founder",
    salaryMin: 0,
    salaryMax: 0,
    equity: 25,
    skills: ["Python", "ML/AI", "Healthcare Domain", "Leadership"],
    postedAt: "1 day ago",
    applicants: 12,
    isVerified: false,
    stage: "Idea",
  },
  {
    id: "3",
    title: "Product Designer (UI/UX) — B2B SaaS",
    company: "SalesMind AI",
    logo: "SM",
    location: "Mumbai",
    isRemote: false,
    type: "Full-time",
    salaryMin: 15,
    salaryMax: 28,
    equity: 0.25,
    skills: ["Figma", "UX Research", "Design Systems", "Prototyping"],
    postedAt: "3 days ago",
    applicants: 58,
    isVerified: true,
    stage: "Series A",
  },
  {
    id: "4",
    title: "AI/ML Engineer — NLP & LLM Specialist",
    company: "ChatBuild",
    logo: "CB",
    location: "Bengaluru / Remote",
    isRemote: true,
    type: "Full-time",
    salaryMin: 30,
    salaryMax: 60,
    equity: 0.75,
    skills: ["Python", "LLMs", "PyTorch", "HuggingFace", "RAG"],
    postedAt: "1 day ago",
    applicants: 21,
    isVerified: true,
    stage: "Seed",
  },
  {
    id: "5",
    title: "Growth Marketing Intern — EdTech Startup",
    company: "LearnSmart",
    logo: "LS",
    location: "Delhi (Hybrid)",
    isRemote: false,
    type: "Internship",
    salaryMin: 15000,
    salaryMax: 25000,
    equity: 0,
    skills: ["Social Media", "Content Marketing", "Analytics", "SEO"],
    postedAt: "5 hours ago",
    applicants: 87,
    isVerified: true,
    stage: "Series A",
  },
  {
    id: "6",
    title: "Sales Development Representative (B2B SaaS)",
    company: "FactoryOS",
    logo: "FO",
    location: "Chennai",
    isRemote: false,
    type: "Full-time",
    salaryMin: 8,
    salaryMax: 15,
    equity: 0,
    skills: ["B2B Sales", "CRM", "Cold Outreach", "Manufacturing Domain"],
    postedAt: "1 week ago",
    applicants: 42,
    isVerified: true,
    stage: "Seed",
  },
];

function JobCard({ job }: { job: typeof MOCK_JOBS[0] }) {
  const isInternship = job.type === "Internship";
  const isCofounder = job.type === "Co-founder";

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="card-premium p-5 group hover:border-primary/30 transition-all"
    >
      <div className="flex items-start gap-4 mb-3">
        <div className="w-12 h-12 rounded-xl brand-gradient flex items-center justify-center text-white font-bold text-sm flex-shrink-0">
          {job.logo}
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-sm leading-snug group-hover:text-primary transition-colors line-clamp-1">
            {job.title}
          </h3>
          <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
            <span className="font-medium text-foreground">{job.company}</span>
            {job.isVerified && <CheckCircle2 className="w-3 h-3 text-blue-500" />}
            <span className="tag text-[10px] ml-1">{job.stage}</span>
          </div>
        </div>
        <span className={cn(
          "badge-level text-[10px] flex-shrink-0",
          isCofounder ? "bg-purple-500/10 text-purple-500" :
          job.type === "Internship" ? "bg-blue-500/10 text-blue-500" :
          "bg-green-500/10 text-green-500"
        )}>
          {job.type}
        </span>
      </div>

      {/* Compensation */}
      <div className="flex items-center gap-4 mb-3 text-xs">
        <span className="flex items-center gap-1 text-muted-foreground">
          <MapPin className="w-3 h-3" />
          {job.location} {job.isRemote && "· Remote OK"}
        </span>
        <span className="flex items-center gap-1 font-medium">
          <DollarSign className="w-3 h-3 text-green-500" />
          {isCofounder
            ? `${job.equity}% equity`
            : isInternship
            ? `₹${(job.salaryMin / 1000).toFixed(0)}K–${(job.salaryMax / 1000).toFixed(0)}K/mo`
            : `₹${job.salaryMin}–${job.salaryMax} LPA`}
          {!isCofounder && !isInternship && job.equity > 0 && ` + ${job.equity}% equity`}
        </span>
      </div>

      {/* Skills */}
      <div className="flex flex-wrap gap-1.5 mb-3">
        {job.skills.slice(0, 4).map((skill) => (
          <span key={skill} className="px-2 py-0.5 rounded bg-surface-2 text-[10px] font-medium">{skill}</span>
        ))}
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between pt-3 border-t border-border">
        <div className="flex items-center gap-3 text-xs text-muted-foreground">
          <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{job.postedAt}</span>
          <span>{job.applicants} applicants</span>
        </div>
        <button className="btn-primary text-xs px-3 py-1.5">
          Apply Now
        </button>
      </div>
    </motion.div>
  );
}

export default function TalentPage() {
  const [search, setSearch] = useState("");
  const [jobType, setJobType] = useState("All");
  const [role, setRole] = useState("All Roles");

  const filtered = MOCK_JOBS.filter((job) => {
    const matchSearch = job.title.toLowerCase().includes(search.toLowerCase()) ||
      job.company.toLowerCase().includes(search.toLowerCase()) ||
      job.skills.some((s) => s.toLowerCase().includes(search.toLowerCase()));
    const matchType = jobType === "All" || job.type === jobType;
    return matchSearch && matchType;
  });

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <Briefcase className="w-6 h-6 text-blue-500" />
            Talent Marketplace
          </h1>
          <p className="text-muted-foreground mt-1 text-sm">
            Join innovative startups or hire top talent. One-click applications.
          </p>
        </div>
        <Link href="/talent/post" className="btn-primary">
          <Plus className="w-4 h-4" /> Post Job
        </Link>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: "Open Positions", value: "4,200+", icon: Briefcase, color: "text-blue-500 bg-blue-500/10" },
          { label: "Startups Hiring", value: "860+", icon: Users, color: "text-violet-500 bg-violet-500/10" },
          { label: "AI Matches/day", value: "1,200+", icon: Brain, color: "text-green-500 bg-green-500/10" },
        ].map((stat) => (
          <div key={stat.label} className="card-premium p-4 flex items-center gap-3">
            <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0", stat.color)}>
              <stat.icon className="w-5 h-5" />
            </div>
            <div>
              <div className="font-bold text-base">{stat.value}</div>
              <div className="text-xs text-muted-foreground">{stat.label}</div>
            </div>
          </div>
        ))}
      </div>

      {/* AI Match Banner */}
      <div className="p-4 rounded-2xl border border-primary/30 bg-primary/5 flex items-center gap-3">
        <div className="w-9 h-9 rounded-xl brand-gradient flex items-center justify-center flex-shrink-0">
          <Zap className="w-4.5 h-4.5 text-white" />
        </div>
        <div className="flex-1">
          <div className="font-semibold text-sm">AI matched 23 jobs to your profile</div>
          <div className="text-xs text-muted-foreground mt-0.5">Skills: React, Node.js, TypeScript, AI/ML · Location: Bengaluru</div>
        </div>
        <button className="btn-primary text-xs px-3 py-1.5 flex-shrink-0">
          View Matches <ArrowRight className="w-3 h-3" />
        </button>
      </div>

      {/* Filters */}
      <div className="space-y-3">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search jobs by title, company, or skills..."
            className="input-premium pl-10"
          />
        </div>
        <div className="flex gap-2 overflow-x-auto no-scrollbar">
          {JOB_TYPES.map((t) => (
            <button
              key={t}
              onClick={() => setJobType(t)}
              className={cn(
                "px-3.5 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-all flex-shrink-0",
                jobType === t
                  ? "bg-primary text-primary-foreground"
                  : "bg-surface-1 border border-border text-muted-foreground hover:text-foreground"
              )}
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      {/* Jobs */}
      <div className="grid sm:grid-cols-2 gap-4">
        {filtered.map((job) => (
          <JobCard key={job.id} job={job} />
        ))}
      </div>
    </div>
  );
}
