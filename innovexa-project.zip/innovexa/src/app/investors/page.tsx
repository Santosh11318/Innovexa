"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import {
  DollarSign, Search, Filter, Star, MapPin, Globe,
  Briefcase, TrendingUp, CheckCircle2, MessageSquare,
  ChevronRight, Building2, Zap, ArrowRight,
} from "lucide-react";
import { cn } from "@/lib/utils/cn";

const INVESTOR_TYPES = ["All", "Angel", "Venture Capital", "Corporate VC", "Family Office", "PE Fund"];
const STAGES = ["All Stages", "Idea", "Pre-Seed", "Seed", "Series A", "Series B", "Growth"];
const INDUSTRIES_FILTER = ["All Industries", "FinTech", "HealthTech", "EdTech", "SaaS", "AI/ML", "CleanTech"];

const MOCK_INVESTORS = [
  {
    id: "1",
    name: "Kavya Reddy",
    type: "Angel Investor",
    firm: "Individual",
    avatar: "KR",
    location: "Bengaluru",
    portfolio: 18,
    totalInvested: "₹12 Cr",
    minTicket: "₹25L",
    maxTicket: "₹2 Cr",
    stages: ["Pre-Seed", "Seed"],
    industries: ["FinTech", "SaaS", "AI/ML"],
    isVerified: true,
    rating: 4.9,
    reviews: 14,
    bio: "Former VP at Razorpay. Angel investing in early-stage B2B SaaS and FinTech. Focus on founders with strong domain expertise.",
    recentInvestments: ["PayEasy", "SalesMind AI", "CreditKart"],
  },
  {
    id: "2",
    name: "Nexus Venture Partners",
    type: "Venture Capital",
    firm: "Nexus Venture Partners",
    avatar: "NV",
    location: "Mumbai / Bengaluru",
    portfolio: 140,
    totalInvested: "₹2500 Cr+",
    minTicket: "₹1 Cr",
    maxTicket: "₹50 Cr",
    stages: ["Seed", "Series A", "Series B"],
    industries: ["SaaS", "FinTech", "HealthTech", "EdTech"],
    isVerified: true,
    rating: 4.8,
    reviews: 62,
    bio: "One of India's leading early-stage VC firms. Invested in Delhivery, Unacademy, Druva and 140+ companies.",
    recentInvestments: ["Delhivery", "Unacademy", "Druva"],
  },
  {
    id: "3",
    name: "Rajesh Mehta",
    type: "Angel Investor",
    firm: "Mehta Family Office",
    avatar: "RM",
    location: "Delhi",
    portfolio: 34,
    totalInvested: "₹35 Cr",
    minTicket: "₹50L",
    maxTicket: "₹5 Cr",
    stages: ["Pre-Seed", "Seed", "Series A"],
    industries: ["AgriTech", "CleanTech", "Manufacturing", "B2B SaaS"],
    isVerified: true,
    rating: 4.7,
    reviews: 28,
    bio: "Serial entrepreneur turned investor. 3 exits including one IPO. Focus on impact-driven businesses solving Bharat's problems.",
    recentInvestments: ["KhetMitra", "SolarGrid", "FactoryOS"],
  },
  {
    id: "4",
    name: "Peak XV Partners",
    type: "Venture Capital",
    firm: "Peak XV Partners (ex-Sequoia India)",
    avatar: "PX",
    location: "Bengaluru / Mumbai",
    portfolio: 400,
    totalInvested: "₹20,000 Cr+",
    minTicket: "₹2 Cr",
    maxTicket: "₹500 Cr",
    stages: ["Seed", "Series A", "Series B", "Growth"],
    industries: ["All Sectors"],
    isVerified: true,
    rating: 4.9,
    reviews: 210,
    bio: "India's most prominent VC firm. Portfolio includes Byju's, Zomato, OYO, Meesho, and 400+ companies.",
    recentInvestments: ["Zomato", "Meesho", "Groww"],
  },
];

function InvestorCard({ investor }: { investor: typeof MOCK_INVESTORS[0] }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="card-premium p-6"
    >
      {/* Header */}
      <div className="flex items-start gap-4 mb-4">
        <div className="w-14 h-14 rounded-2xl brand-gradient flex items-center justify-center text-white font-bold text-lg flex-shrink-0">
          {investor.avatar}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <h3 className="font-bold text-base">{investor.name}</h3>
            {investor.isVerified && (
              <CheckCircle2 className="w-4 h-4 text-blue-500 flex-shrink-0" />
            )}
          </div>
          <div className="text-sm text-muted-foreground">{investor.type} · {investor.firm}</div>
          <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
            <span className="flex items-center gap-1"><MapPin className="w-3 h-3" />{investor.location}</span>
            <span className="flex items-center gap-1"><Star className="w-3 h-3 text-yellow-500" />{investor.rating} ({investor.reviews})</span>
          </div>
        </div>
        <div className="text-right flex-shrink-0">
          <div className="text-xs text-muted-foreground">Portfolio</div>
          <div className="font-bold text-lg">{investor.portfolio}</div>
          <div className="text-xs text-muted-foreground">companies</div>
        </div>
      </div>

      {/* Bio */}
      <p className="text-xs text-muted-foreground leading-relaxed mb-4 line-clamp-2">
        {investor.bio}
      </p>

      {/* Investment info */}
      <div className="grid grid-cols-3 gap-3 p-3 rounded-xl bg-surface-1 border border-border mb-4">
        <div className="text-center">
          <div className="text-xs text-muted-foreground">Ticket Size</div>
          <div className="text-xs font-semibold mt-0.5">{investor.minTicket} – {investor.maxTicket}</div>
        </div>
        <div className="text-center border-x border-border">
          <div className="text-xs text-muted-foreground">Stages</div>
          <div className="text-xs font-semibold mt-0.5">{investor.stages.slice(0, 2).join(", ")}</div>
        </div>
        <div className="text-center">
          <div className="text-xs text-muted-foreground">Total</div>
          <div className="text-xs font-semibold mt-0.5">{investor.totalInvested}</div>
        </div>
      </div>

      {/* Industries */}
      <div className="flex flex-wrap gap-1.5 mb-4">
        {investor.industries.slice(0, 4).map((ind) => (
          <span key={ind} className="tag text-[10px]">{ind}</span>
        ))}
      </div>

      {/* Actions */}
      <div className="flex items-center gap-2">
        <button className="btn-secondary flex-1 text-xs gap-1.5 py-2">
          <MessageSquare className="w-3.5 h-3.5" /> Message
        </button>
        <button className="btn-primary flex-1 text-xs gap-1.5 py-2">
          <Briefcase className="w-3.5 h-3.5" /> Request Meeting
        </button>
      </div>
    </motion.div>
  );
}

export default function InvestorsPage() {
  const [search, setSearch] = useState("");
  const [type, setType] = useState("All");
  const [stage, setStage] = useState("All Stages");

  const filtered = MOCK_INVESTORS.filter((inv) => {
    const matchSearch = inv.name.toLowerCase().includes(search.toLowerCase()) ||
      inv.bio.toLowerCase().includes(search.toLowerCase());
    const matchType = type === "All" || inv.type.includes(type);
    return matchSearch && matchType;
  });

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <DollarSign className="w-6 h-6 text-green-500" />
            Investor Hub
          </h1>
          <p className="text-muted-foreground mt-1 text-sm">
            Connect with verified angel investors, VCs, and family offices.
          </p>
        </div>
        <button className="btn-primary">
          <Zap className="w-4 h-4" /> AI Match Investors
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: "Verified Investors", value: "2,400+", icon: CheckCircle2, color: "text-green-500 bg-green-500/10" },
          { label: "Total Capital Available", value: "₹5,000 Cr+", icon: DollarSign, color: "text-yellow-500 bg-yellow-500/10" },
          { label: "Successful Deals", value: "1,200+", icon: TrendingUp, color: "text-blue-500 bg-blue-500/10" },
        ].map((stat) => (
          <div key={stat.label} className="card-premium p-4 flex items-center gap-3">
            <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0", stat.color)}>
              <stat.icon className="w-5 h-5" />
            </div>
            <div>
              <div className="font-bold text-base">{stat.value}</div>
              <div className="text-xs text-muted-foreground">{stat.label}</div>
            </div>
          </div>
        ))}
      </div>

      {/* AI Banner */}
      <div className="p-4 rounded-2xl border border-primary/30 bg-primary/5 flex items-center gap-3">
        <div className="w-9 h-9 rounded-xl brand-gradient flex items-center justify-center flex-shrink-0">
          <Zap className="w-4.5 h-4.5 text-white" />
        </div>
        <div className="flex-1">
          <div className="font-semibold text-sm">AI found 8 investors matching your startup profile</div>
          <div className="text-xs text-muted-foreground mt-0.5">Based on: FinStack AI · Seed Stage · FinTech + AI</div>
        </div>
        <button className="btn-primary text-xs px-3 py-1.5 flex-shrink-0">
          View Matches <ArrowRight className="w-3 h-3" />
        </button>
      </div>

      {/* Filters */}
      <div className="space-y-3">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search investors by name, firm, or focus area..."
            className="input-premium pl-10"
          />
        </div>
        <div className="flex gap-2 overflow-x-auto no-scrollbar">
          {INVESTOR_TYPES.map((t) => (
            <button
              key={t}
              onClick={() => setType(t)}
              className={cn(
                "px-3.5 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-all flex-shrink-0",
                type === t
                  ? "bg-primary text-primary-foreground"
                  : "bg-surface-1 border border-border text-muted-foreground hover:text-foreground"
              )}
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      {/* Grid */}
      <div className="grid sm:grid-cols-2 gap-5">
        {filtered.map((investor) => (
          <InvestorCard key={investor.id} investor={investor} />
        ))}
      </div>
    </div>
  );
}
