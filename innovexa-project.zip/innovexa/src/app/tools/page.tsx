"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import {
  Wrench, Calculator, BarChart3, DollarSign, TrendingUp,
  PieChart, Target, Percent, Users, Clock, ChevronRight,
} from "lucide-react";

const TOOLS = [
  {
    id: "runway",
    icon: Clock,
    label: "Runway Calculator",
    desc: "How long can your startup survive?",
    color: "from-red-500 to-orange-500",
    fields: [
      { key: "cash", label: "Current Cash (₹)", placeholder: "e.g. 5000000" },
      { key: "burn", label: "Monthly Burn Rate (₹)", placeholder: "e.g. 400000" },
      { key: "revenue", label: "Monthly Revenue (₹)", placeholder: "e.g. 100000" },
    ],
    compute: (v: Record<string, number>) => {
      const netBurn = v.burn - v.revenue;
      if (netBurn <= 0) return { result: "∞ months (profitable!)", type: "success" };
      const months = Math.floor(v.cash / netBurn);
      return {
        result: `${months} months runway`,
        type: months < 6 ? "danger" : months < 12 ? "warning" : "success",
        detail: `At ₹${((netBurn) / 1000).toFixed(0)}K net burn/month`,
      };
    },
  },
  {
    id: "cac_ltv",
    icon: Target,
    label: "CAC / LTV Calculator",
    desc: "Unit economics health check",
    color: "from-blue-500 to-cyan-500",
    fields: [
      { key: "marketing", label: "Monthly Marketing Spend (₹)", placeholder: "e.g. 100000" },
      { key: "newCustomers", label: "New Customers/Month", placeholder: "e.g. 50" },
      { key: "avgRevenue", label: "Avg Revenue per Customer (₹)", placeholder: "e.g. 5000" },
      { key: "churnRate", label: "Monthly Churn Rate (%)", placeholder: "e.g. 5" },
    ],
    compute: (v: Record<string, number>) => {
      const cac = v.marketing / (v.newCustomers || 1);
      const ltv = v.avgRevenue / ((v.churnRate || 1) / 100);
      const ratio = ltv / cac;
      return {
        result: `LTV:CAC = ${ratio.toFixed(1)}x`,
        type: ratio >= 3 ? "success" : ratio >= 1 ? "warning" : "danger",
        detail: `CAC: ₹${cac.toFixed(0)} | LTV: ₹${ltv.toFixed(0)}`,
      };
    },
  },
  {
    id: "equity",
    icon: PieChart,
    label: "Equity Dilution Calculator",
    desc: "Calculate founder dilution after funding",
    color: "from-purple-500 to-violet-500",
    fields: [
      { key: "founderShares", label: "Founder Shares (%)", placeholder: "e.g. 100" },
      { key: "investorPercent", label: "Investor Gets (%)", placeholder: "e.g. 20" },
      { key: "esop", label: "ESOP Pool (%)", placeholder: "e.g. 10" },
    ],
    compute: (v: Record<string, number>) => {
      const remaining = 100 - v.investorPercent - v.esop;
      const founderAfter = (v.founderShares / 100) * remaining;
      return {
        result: `Founder retains ${founderAfter.toFixed(1)}%`,
        type: founderAfter > 50 ? "success" : founderAfter > 30 ? "warning" : "danger",
        detail: `Investor: ${v.investorPercent}% | ESOP: ${v.esop}% | Founder: ${founderAfter.toFixed(1)}%`,
      };
    },
  },
  {
    id: "roi",
    icon: TrendingUp,
    label: "ROI Calculator",
    desc: "Return on investment analysis",
    color: "from-green-500 to-emerald-500",
    fields: [
      { key: "investment", label: "Total Investment (₹)", placeholder: "e.g. 1000000" },
      { key: "revenue", label: "Total Revenue Generated (₹)", placeholder: "e.g. 1800000" },
      { key: "costs", label: "Additional Costs (₹)", placeholder: "e.g. 200000" },
    ],
    compute: (v: Record<string, number>) => {
      const netProfit = v.revenue - v.costs - v.investment;
      const roi = (netProfit / v.investment) * 100;
      return {
        result: `ROI: ${roi.toFixed(1)}%`,
        type: roi > 20 ? "success" : roi > 0 ? "warning" : "danger",
        detail: `Net Profit: ₹${(netProfit / 1000).toFixed(0)}K`,
      };
    },
  },
  {
    id: "burn",
    icon: BarChart3,
    label: "Burn Rate Tracker",
    desc: "Track your monthly spending",
    color: "from-orange-500 to-amber-500",
    fields: [
      { key: "salaries", label: "Salaries (₹/month)", placeholder: "e.g. 300000" },
      { key: "infrastructure", label: "Infrastructure (₹/month)", placeholder: "e.g. 50000" },
      { key: "marketing", label: "Marketing (₹/month)", placeholder: "e.g. 100000" },
      { key: "other", label: "Other Expenses (₹/month)", placeholder: "e.g. 50000" },
    ],
    compute: (v: Record<string, number>) => {
      const total = Object.values(v).reduce((a, b) => a + b, 0);
      return {
        result: `₹${(total / 1000).toFixed(0)}K/month burn`,
        type: total < 500000 ? "success" : total < 1000000 ? "warning" : "danger",
        detail: `₹${(total * 12 / 100000).toFixed(1)} Lakhs/year`,
      };
    },
  },
  {
    id: "valuation",
    icon: DollarSign,
    label: "Startup Valuation (Quick)",
    desc: "Estimate your pre-money valuation",
    color: "from-yellow-500 to-amber-500",
    fields: [
      { key: "arr", label: "Annual Recurring Revenue (₹)", placeholder: "e.g. 5000000" },
      { key: "multiple", label: "Industry Revenue Multiple (x)", placeholder: "e.g. 10" },
      { key: "growth", label: "Annual Growth Rate (%)", placeholder: "e.g. 200" },
    ],
    compute: (v: Record<string, number>) => {
      const base = v.arr * v.multiple;
      const growthAdj = base * (1 + v.growth / 100);
      return {
        result: `~₹${(growthAdj / 10000000).toFixed(1)} Cr valuation`,
        type: "success",
        detail: `Base: ₹${(base / 10000000).toFixed(1)} Cr | Growth adjusted: ₹${(growthAdj / 10000000).toFixed(1)} Cr`,
      };
    },
  },
];

interface ToolResult {
  result: string;
  type: "success" | "warning" | "danger";
  detail?: string;
}

function ToolCard({ tool }: { tool: typeof TOOLS[0] }) {
  const [values, setValues] = useState<Record<string, string>>({});
  const [result, setResult] = useState<ToolResult | null>(null);

  const compute = () => {
    const numValues: Record<string, number> = {};
    for (const field of tool.fields) {
      numValues[field.key] = parseFloat(values[field.key] || "0") || 0;
    }
    setResult(tool.compute(numValues) as ToolResult);
  };

  const resultColors = {
    success: "bg-green-500/10 border-green-500/30 text-green-600 dark:text-green-400",
    warning: "bg-yellow-500/10 border-yellow-500/30 text-yellow-600 dark:text-yellow-400",
    danger: "bg-red-500/10 border-red-500/30 text-red-600 dark:text-red-400",
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="card-premium p-5"
    >
      {/* Header */}
      <div className="flex items-center gap-3 mb-4">
        <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${tool.color} flex items-center justify-center flex-shrink-0`}>
          <tool.icon className="w-5 h-5 text-white" />
        </div>
        <div>
          <h3 className="font-semibold text-sm">{tool.label}</h3>
          <p className="text-xs text-muted-foreground">{tool.desc}</p>
        </div>
      </div>

      {/* Inputs */}
      <div className="space-y-3 mb-4">
        {tool.fields.map((field) => (
          <div key={field.key} className="space-y-1">
            <label className="text-xs font-medium text-muted-foreground">{field.label}</label>
            <input
              type="number"
              value={values[field.key] || ""}
              onChange={(e) => setValues({ ...values, [field.key]: e.target.value })}
              placeholder={field.placeholder}
              className="input-premium py-2 text-sm"
            />
          </div>
        ))}
      </div>

      <button onClick={compute} className="btn-primary w-full text-sm gap-2">
        <Calculator className="w-4 h-4" /> Calculate
      </button>

      {result && (
        <motion.div
          initial={{ opacity: 0, scale: 0.97 }}
          animate={{ opacity: 1, scale: 1 }}
          className={`mt-4 p-3 rounded-xl border ${resultColors[result.type]}`}
        >
          <div className="font-bold text-base">{result.result}</div>
          {result.detail && <div className="text-xs mt-1 opacity-80">{result.detail}</div>}
        </motion.div>
      )}
    </motion.div>
  );
}

export default function ToolsPage() {
  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
          <Wrench className="w-6 h-6 text-blue-500" />
          Business Tools
        </h1>
        <p className="text-muted-foreground mt-1 text-sm">
          Free calculators and tools for startup founders. No spreadsheet needed.
        </p>
      </div>

      {/* Tools Grid */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {TOOLS.map((tool) => (
          <ToolCard key={tool.id} tool={tool} />
        ))}
      </div>

      {/* Coming soon */}
      <div className="card-premium p-5">
        <h2 className="font-semibold mb-3">More Tools Coming Soon</h2>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[
            "GST Calculator", "Cap Table Builder", "OKR Tracker",
            "KPI Dashboard", "Invoice Generator", "ESOP Calculator",
            "Break-even Analysis", "Financial Model Generator",
          ].map((tool) => (
            <div key={tool} className="px-3 py-2 rounded-xl bg-surface-1 border border-dashed border-border text-xs text-muted-foreground text-center">
              {tool}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
