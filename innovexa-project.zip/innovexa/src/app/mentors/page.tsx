"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import {
  GraduationCap, Search, Star, MapPin, Clock, CheckCircle2,
  Calendar, Video, MessageSquare, Zap, ArrowRight, DollarSign,
} from "lucide-react";
import { cn } from "@/lib/utils/cn";

const EXPERTISE = ["All", "Startup Building", "Fundraising", "Product", "Marketing", "Tech", "Finance", "Legal", "Sales", "HR"];

const MOCK_MENTORS = [
  {
    id: "1",
    name: "Ananya Krishnan",
    avatar: "AK",
    headline: "3x Founder | Ex-Flipkart VP | Angel Investor",
    location: "Bengaluru",
    expertise: ["Startup Building", "Fundraising", "Product"],
    sessions: 312,
    rating: 4.95,
    reviews: 89,
    isFree: false,
    hourlyRate: 2000,
    isVerified: true,
    availability: "Available this week",
    bio: "Founded 3 companies, 2 exits. Former VP Product at Flipkart. Mentored 50+ founders who raised over ₹100 Cr collectively.",
    languages: ["English", "Hindi", "Tamil"],
  },
  {
    id: "2",
    name: "Suresh Balasubramanian",
    avatar: "SB",
    headline: "IIT Bombay | 20 yrs in B2B SaaS | CTO turned advisor",
    location: "Chennai",
    expertise: ["Tech", "Product", "Startup Building"],
    sessions: 187,
    rating: 4.88,
    reviews: 52,
    isFree: true,
    hourlyRate: 0,
    isVerified: true,
    availability: "Next available: Tomorrow",
    bio: "20 years building enterprise SaaS products. Currently advising 5 startups. Passionate about helping technical founders with product strategy.",
    languages: ["English", "Tamil"],
  },
  {
    id: "3",
    name: "Nisha Agarwal",
    avatar: "NA",
    headline: "Marketing & Growth Expert | Ex-Meesho, MakeMyTrip",
    location: "Mumbai",
    expertise: ["Marketing", "Sales", "Startup Building"],
    sessions: 424,
    rating: 4.92,
    reviews: 134,
    isFree: false,
    hourlyRate: 3000,
    isVerified: true,
    availability: "Available today",
    bio: "Built marketing at Meesho from 0 to 1M users. Helped 100+ startups with go-to-market strategy. Specialist in growth hacking for Indian market.",
    languages: ["English", "Hindi", "Marathi"],
  },
  {
    id: "4",
    name: "Arjun Kapoor",
    avatar: "AK2",
    headline: "CA | Startup CFO | 50+ funding rounds experience",
    location: "Delhi",
    expertise: ["Finance", "Fundraising", "Legal"],
    sessions: 256,
    rating: 4.85,
    reviews: 71,
    isFree: false,
    hourlyRate: 2500,
    isVerified: true,
    availability: "Available this week",
    bio: "Chartered Accountant with 12 years helping startups with financial modeling, fundraising, ESOP structuring, and DPIIT registration.",
    languages: ["English", "Hindi"],
  },
];

function MentorCard({ mentor }: { mentor: typeof MOCK_MENTORS[0] }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="card-premium p-6"
    >
      {/* Header */}
      <div className="flex items-start gap-4 mb-4">
        <div className="relative">
          <div className="w-14 h-14 rounded-2xl brand-gradient flex items-center justify-center text-white font-bold text-lg flex-shrink-0">
            {mentor.avatar.slice(0, 2)}
          </div>
          <div className="status-dot-online absolute -bottom-0.5 -right-0.5" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <h3 className="font-bold text-base">{mentor.name}</h3>
            {mentor.isVerified && <CheckCircle2 className="w-4 h-4 text-blue-500 flex-shrink-0" />}
          </div>
          <div className="text-xs text-muted-foreground mt-0.5 line-clamp-1">{mentor.headline}</div>
          <div className="flex items-center gap-3 mt-1.5 text-xs text-muted-foreground">
            <span className="flex items-center gap-1"><MapPin className="w-3 h-3" />{mentor.location}</span>
            <span className="flex items-center gap-1"><Star className="w-3 h-3 text-yellow-500 fill-yellow-500" />{mentor.rating} ({mentor.reviews})</span>
          </div>
        </div>
        <div className="text-right flex-shrink-0">
          {mentor.isFree ? (
            <span className="badge-level bg-green-500/10 text-green-500">Free</span>
          ) : (
            <div>
              <div className="font-bold text-sm">₹{mentor.hourlyRate.toLocaleString()}</div>
              <div className="text-xs text-muted-foreground">/hour</div>
            </div>
          )}
        </div>
      </div>

      <p className="text-xs text-muted-foreground leading-relaxed mb-4 line-clamp-2">{mentor.bio}</p>

      {/* Stats */}
      <div className="flex items-center gap-4 mb-4 py-3 border-y border-border">
        <div className="text-center flex-1">
          <div className="font-bold text-sm">{mentor.sessions}</div>
          <div className="text-[10px] text-muted-foreground">Sessions</div>
        </div>
        <div className="text-center flex-1">
          <div className="font-bold text-sm">{mentor.expertise.length}</div>
          <div className="text-[10px] text-muted-foreground">Expertise</div>
        </div>
        <div className="text-center flex-1">
          <div className="text-xs font-medium text-green-500">{mentor.availability}</div>
          <div className="text-[10px] text-muted-foreground">Availability</div>
        </div>
      </div>

      {/* Tags */}
      <div className="flex flex-wrap gap-1.5 mb-4">
        {mentor.expertise.map((e) => (
          <span key={e} className="tag text-[10px]">{e}</span>
        ))}
      </div>

      {/* Actions */}
      <div className="flex gap-2">
        <button className="btn-secondary flex-1 text-xs gap-1.5 py-2">
          <MessageSquare className="w-3.5 h-3.5" /> Message
        </button>
        <button className="btn-primary flex-1 text-xs gap-1.5 py-2">
          <Calendar className="w-3.5 h-3.5" /> Book Session
        </button>
      </div>
    </motion.div>
  );
}

export default function MentorsPage() {
  const [search, setSearch] = useState("");
  const [expertise, setExpertise] = useState("All");
  const [freeOnly, setFreeOnly] = useState(false);

  const filtered = MOCK_MENTORS.filter((m) => {
    const matchSearch = m.name.toLowerCase().includes(search.toLowerCase()) ||
      m.bio.toLowerCase().includes(search.toLowerCase());
    const matchExpertise = expertise === "All" || m.expertise.includes(expertise);
    const matchFree = !freeOnly || m.isFree;
    return matchSearch && matchExpertise && matchFree;
  });

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <GraduationCap className="w-6 h-6 text-yellow-500" />
            Mentor Hub
          </h1>
          <p className="text-muted-foreground mt-1 text-sm">
            Book sessions with India's top startup mentors. Free & paid options.
          </p>
        </div>
        <button className="btn-primary">
          <Zap className="w-4 h-4" /> Find My Mentor
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: "Expert Mentors", value: "800+", icon: GraduationCap, color: "text-yellow-500 bg-yellow-500/10" },
          { label: "Sessions Completed", value: "24,000+", icon: Video, color: "text-blue-500 bg-blue-500/10" },
          { label: "Avg Rating", value: "4.8★", icon: Star, color: "text-orange-500 bg-orange-500/10" },
        ].map((stat) => (
          <div key={stat.label} className="card-premium p-4 flex items-center gap-3">
            <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0", stat.color)}>
              <stat.icon className="w-5 h-5" />
            </div>
            <div>
              <div className="font-bold text-base">{stat.value}</div>
              <div className="text-xs text-muted-foreground">{stat.label}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="space-y-3">
        <div className="flex gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search mentors by name or expertise..."
              className="input-premium pl-10"
            />
          </div>
          <label className="flex items-center gap-2 px-4 py-2 rounded-xl border border-border bg-surface-1 cursor-pointer text-sm font-medium">
            <input
              type="checkbox"
              checked={freeOnly}
              onChange={(e) => setFreeOnly(e.target.checked)}
              className="accent-primary"
            />
            Free Only
          </label>
        </div>
        <div className="flex gap-2 overflow-x-auto no-scrollbar">
          {EXPERTISE.map((e) => (
            <button
              key={e}
              onClick={() => setExpertise(e)}
              className={cn(
                "px-3.5 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-all flex-shrink-0",
                expertise === e
                  ? "bg-primary text-primary-foreground"
                  : "bg-surface-1 border border-border text-muted-foreground hover:text-foreground"
              )}
            >
              {e}
            </button>
          ))}
        </div>
      </div>

      {/* Mentor grid */}
      <div className="grid sm:grid-cols-2 gap-5">
        {filtered.map((mentor) => (
          <MentorCard key={mentor.id} mentor={mentor} />
        ))}
      </div>
    </div>
  );
}
