"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import {
  Target, Search, Filter, Plus, Clock, Users, DollarSign,
  TrendingUp, Award, ChevronRight, Zap, X, SlidersHorizontal,
  Globe, Brain, Factory, Heart, ShoppingCart, Building,
} from "lucide-react";
import Link from "next/link";
import { cn } from "@/lib/utils/cn";

const CATEGORIES = [
  { label: "All", value: "all", icon: Globe },
  { label: "AI & Tech", value: "ai_tech", icon: Brain },
  { label: "HealthTech", value: "health", icon: Heart },
  { label: "FinTech", value: "fintech", icon: DollarSign },
  { label: "E-commerce", value: "ecommerce", icon: ShoppingCart },
  { label: "Manufacturing", value: "manufacturing", icon: Factory },
  { label: "SaaS", value: "saas", icon: Building },
];

const REWARD_TYPES = ["All", "Cash", "Employment", "Equity", "Partnership", "Internship"];

const MOCK_PROBLEMS = [
  {
    id: "1",
    title: "Need AI-powered demand forecasting system for D2C fashion brand",
    description: "We're a D2C fashion brand doing ₹5Cr/month. Need an AI system that can predict inventory demand 3 months ahead based on trends, weather, festivals, and social media signals.",
    category: "AI & Tech",
    industry: ["E-commerce", "AI"],
    author: { name: "Rohit Khanna", role: "Founder, StyleAI", avatar: "RK" },
    rewards: ["Cash"],
    cashReward: 50000,
    deadline: "5 days",
    solutions: 3,
    views: 234,
    status: "OPEN",
    isFeatured: true,
    postedAt: "2 days ago",
  },
  {
    id: "2",
    title: "Healthcare telemedicine platform needs ABDM integration",
    description: "Our telemedicine app has 50k+ users. We need a developer who can integrate Ayushman Bharat Digital Mission (ABDM) APIs for health record management.",
    category: "HealthTech",
    industry: ["Healthcare", "Government"],
    author: { name: "Dr. Priya Verma", role: "Founder, MedConnect", avatar: "PV" },
    rewards: ["Employment", "Equity"],
    cashReward: null,
    deadline: "12 days",
    solutions: 7,
    views: 180,
    status: "OPEN",
    isFeatured: false,
    postedAt: "3 days ago",
  },
  {
    id: "3",
    title: "Logistics startup needs route optimization algorithm",
    description: "We do last-mile delivery in Tier 2 cities. Our current manual routing wastes 30% of fuel. Need an optimization algorithm that accounts for Indian road conditions.",
    category: "Logistics",
    industry: ["Logistics", "AI"],
    author: { name: "Aakash Mehta", role: "CTO, QuickDeliver", avatar: "AM" },
    rewards: ["Cash", "Partnership"],
    cashReward: 75000,
    deadline: "8 days",
    solutions: 12,
    views: 412,
    status: "OPEN",
    isFeatured: true,
    postedAt: "1 day ago",
  },
  {
    id: "4",
    title: "EdTech platform needs adaptive learning engine",
    description: "We have 1 lakh+ students on our K-12 platform. Need an adaptive learning system that personalizes content based on student performance and learning style.",
    category: "EdTech",
    industry: ["Education", "AI"],
    author: { name: "Sanya Gupta", role: "CEO, LearnSmart", avatar: "SG" },
    rewards: ["Equity", "Partnership"],
    cashReward: null,
    deadline: "20 days",
    solutions: 5,
    views: 156,
    status: "OPEN",
    isFeatured: false,
    postedAt: "5 days ago",
  },
  {
    id: "5",
    title: "FinTech needs credit scoring model for unbanked population",
    description: "Building a lending app for rural India. Need an ML model that can assess creditworthiness using alternative data (mobile usage, utility bills, merchant transactions).",
    category: "FinTech",
    industry: ["Finance", "AI", "Rural"],
    author: { name: "Vikram Singh", role: "Founder, RuralFin", avatar: "VS" },
    rewards: ["Cash", "Employment"],
    cashReward: 100000,
    deadline: "15 days",
    solutions: 9,
    views: 521,
    status: "OPEN",
    isFeatured: true,
    postedAt: "6 hours ago",
  },
  {
    id: "6",
    title: "Manufacturing SME needs IoT-based predictive maintenance",
    description: "We operate a textile manufacturing unit in Surat. Machines break down unpredictably costing us ₹10L/month. Need an IoT solution for predictive maintenance.",
    category: "Manufacturing",
    industry: ["Manufacturing", "IoT"],
    author: { name: "Haresh Patel", role: "MD, SuratTextiles", avatar: "HP" },
    rewards: ["Cash", "Revenue Sharing"],
    cashReward: 200000,
    deadline: "30 days",
    solutions: 4,
    views: 298,
    status: "OPEN",
    isFeatured: false,
    postedAt: "1 week ago",
  },
];

function ProblemCard({ problem }: { problem: typeof MOCK_PROBLEMS[0] }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="card-premium p-5 group"
    >
      {/* Header */}
      <div className="flex items-start gap-3 mb-3">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1.5 flex-wrap">
            {problem.isFeatured && (
              <span className="badge-level bg-yellow-500/10 text-yellow-500">
                <TrendingUp className="w-3 h-3" /> Featured
              </span>
            )}
            <span className="tag">{problem.category}</span>
            <span className="text-xs text-muted-foreground">{problem.postedAt}</span>
          </div>
          <h3 className="font-semibold text-sm leading-snug group-hover:text-primary transition-colors">
            {problem.title}
          </h3>
        </div>
      </div>

      <p className="text-xs text-muted-foreground leading-relaxed line-clamp-2 mb-4">
        {problem.description}
      </p>

      {/* Rewards */}
      <div className="flex flex-wrap gap-1.5 mb-4">
        {problem.cashReward && (
          <span className="badge-level bg-green-500/10 text-green-500">
            <DollarSign className="w-3 h-3" />
            ₹{(problem.cashReward / 1000).toFixed(0)}K Cash
          </span>
        )}
        {problem.rewards.filter(r => r !== "Cash").map(reward => (
          <span key={reward} className="badge-level bg-blue-500/10 text-blue-500">
            {reward}
          </span>
        ))}
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between pt-3 border-t border-border">
        <div className="flex items-center gap-3 text-xs text-muted-foreground">
          <span className="flex items-center gap-1">
            <Clock className="w-3 h-3" /> {problem.deadline}
          </span>
          <span className="flex items-center gap-1">
            <Users className="w-3 h-3" /> {problem.solutions} solutions
          </span>
          <span>{problem.views} views</span>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5">
            <div className="avatar w-6 h-6 text-[10px]">{problem.author.avatar}</div>
            <span className="text-xs text-muted-foreground hidden sm:block">{problem.author.name}</span>
          </div>
          <Link
            href={`/problems/${problem.id}`}
            className="btn-primary text-xs px-3 py-1.5"
          >
            Solve <ChevronRight className="w-3 h-3" />
          </Link>
        </div>
      </div>
    </motion.div>
  );
}

export default function ProblemsPage() {
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedReward, setSelectedReward] = useState("All");
  const [searchQuery, setSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState("featured");

  const filtered = MOCK_PROBLEMS.filter((p) => {
    const matchesSearch = p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesReward = selectedReward === "All" || p.rewards.includes(selectedReward);
    return matchesSearch && matchesReward;
  });

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <Target className="w-6 h-6 text-orange-500" />
            Problem Marketplace
          </h1>
          <p className="text-muted-foreground mt-1 text-sm">
            Solve real business challenges. Earn cash, employment, equity, and more.
          </p>
        </div>
        <Link href="/problems/new" className="btn-primary">
          <Plus className="w-4 h-4" /> Post Problem
        </Link>
      </div>

      {/* Stats Banner */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: "Active Problems", value: "1,240+", icon: Target, color: "text-orange-500 bg-orange-500/10" },
          { label: "Total Rewards", value: "₹2.4 Cr+", icon: DollarSign, color: "text-green-500 bg-green-500/10" },
          { label: "Problems Solved", value: "3,200+", icon: Award, color: "text-blue-500 bg-blue-500/10" },
        ].map((stat) => (
          <div key={stat.label} className="card-premium p-4 flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl ${stat.color} flex items-center justify-center flex-shrink-0`}>
              <stat.icon className="w-5 h-5" />
            </div>
            <div>
              <div className="font-bold text-lg">{stat.value}</div>
              <div className="text-xs text-muted-foreground">{stat.label}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="space-y-3">
        {/* Search */}
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search problems by title, category, or skills..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="input-premium pl-10 pr-4"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery("")}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Category pills */}
        <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
          {CATEGORIES.map((cat) => (
            <button
              key={cat.value}
              onClick={() => setSelectedCategory(cat.value)}
              className={cn(
                "flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-all flex-shrink-0",
                selectedCategory === cat.value
                  ? "bg-primary text-primary-foreground"
                  : "bg-surface-1 border border-border text-muted-foreground hover:text-foreground"
              )}
            >
              <cat.icon className="w-3.5 h-3.5" />
              {cat.label}
            </button>
          ))}
        </div>

        {/* Reward filter & Sort */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 flex-wrap">
            {REWARD_TYPES.map((type) => (
              <button
                key={type}
                onClick={() => setSelectedReward(type)}
                className={cn(
                  "px-3 py-1.5 rounded-lg text-xs font-medium transition-all",
                  selectedReward === type
                    ? "bg-primary/15 text-primary border border-primary/30"
                    : "bg-surface-1 border border-border text-muted-foreground hover:text-foreground"
                )}
              >
                {type}
              </button>
            ))}
          </div>

          <div className="ml-auto flex items-center gap-2">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="input-premium py-2 text-sm w-auto"
            >
              <option value="featured">Featured</option>
              <option value="newest">Newest</option>
              <option value="reward">Highest Reward</option>
              <option value="deadline">Deadline</option>
            </select>
          </div>
        </div>
      </div>

      {/* AI Match Banner */}
      <div className="p-4 rounded-2xl border border-primary/30 bg-primary/5 flex items-center gap-3">
        <div className="w-9 h-9 rounded-xl brand-gradient flex items-center justify-center flex-shrink-0">
          <Zap className="w-4.5 h-4.5 text-white" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="font-semibold text-sm">AI matched 12 problems to your skills</div>
          <div className="text-xs text-muted-foreground mt-0.5">Based on your profile: AI Engineering, Python, React</div>
        </div>
        <button className="btn-primary text-xs px-3 py-1.5 flex-shrink-0">
          View Matches
        </button>
      </div>

      {/* Problems Grid */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <p className="text-sm text-muted-foreground">
            Showing <span className="font-semibold text-foreground">{filtered.length}</span> problems
          </p>
        </div>

        {filtered.map((problem) => (
          <ProblemCard key={problem.id} problem={problem} />
        ))}
      </div>
    </div>
  );
}
